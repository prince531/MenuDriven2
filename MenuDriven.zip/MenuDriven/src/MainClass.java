import java.util.Scanner;
import pkg.SimpleInterest;
import pkg.Speed;
public class MainClass {

	public static void main(String[] args) {
		double principal;
		double rate;
		double time;
		double distance;
		double result;
		int choice = 0;
		SimpleInterestImpl simpleInterestImpl = new SimpleInterestImpl();
		SpeedImpl speedImpl = new SpeedImpl();
		
		Scanner sc = new Scanner(System.in);
		
		while(choice!=3) {
			System.out.println("1. SimpleInterest");
			System.out.println("2. Speed");
			System.out.println("3. Exit");
			System.out.println("Enter your choice : ");
			choice = sc.nextInt();
			switch(choice) {
			case 1: 
				System.out.println("Enter principal : ");
				principal = sc.nextDouble();
				System.out.println("Enter rate : ");
				rate = sc.nextDouble();
				System.out.println("Enter time : ");
				time = sc.nextDouble();
				SimpleInterest simpleInterest = new SimpleInterest(principal,rate,time);
				result = simpleInterestImpl.intrest(simpleInterest);
				System.out.println("SimpleInterest = "+ result);
				System.out.println();
				break;
			case 2:
				System.out.println("Enter distance : ");
				distance = sc.nextDouble();
				System.out.println("Enter time : ");
				time = sc.nextDouble();
				Speed speed = new Speed(distance,time);
				result = speedImpl.speeds(speed);
				System.out.println("Speed = "+ result);
				System.out.println();
				break;
			case 3:
				System.exit(0);
				default:System.out.println("Wrong choice try again!!!");
			}
		}
		sc.close();
	}
}
