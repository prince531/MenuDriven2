package pkg;

public class SimpleInterest {
	private double princpal;
	private double rate;
	private double time;
	
	public SimpleInterest() {
		super();
	}

	public SimpleInterest(double princpal, double rate, double time) {
		super();
		this.princpal = princpal;
		this.rate = rate;
		this.time = time;
	}

	public double getPrincpal() {
		return princpal;
	}

	public void setPrincpal(double princpal) {
		this.princpal = princpal;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}
	
}
