package pkg;

public class Speed {
	private double distance;
	private double time;
	public Speed() {
		super();
		
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public double getTime() {
		return time;
	}
	public void setTime(double time) {
		this.time = time;
	}
	public Speed(double distance, double time) {
		super();
		this.distance = distance;
		this.time = time;
	}
	
	
}
