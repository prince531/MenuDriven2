package pkg;

public interface SpeedIntf {
	public double speeds(Speed speed);
}
