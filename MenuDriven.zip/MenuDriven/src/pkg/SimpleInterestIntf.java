package pkg;

public interface SimpleInterestIntf {
	public double intrest(SimpleInterest simpleInterest);
}
