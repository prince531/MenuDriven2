import pkg.Speed;
import pkg.SpeedIntf;

public class SpeedImpl extends SimpleInterestImpl implements SpeedIntf {
	
	double distance;
	public double speeds(Speed speed) {
		distance = speed.getDistance();
	    time = speed.getTime();
		result = distance/time;
		return result;
	}
}
