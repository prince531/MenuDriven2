import pkg.SimpleInterest;
import pkg.SimpleInterestIntf;

public class SimpleInterestImpl implements SimpleInterestIntf {

	double principal;
	double rate;
	double time;
	double result;

	public double intrest(SimpleInterest simpleInterest) {
		principal = simpleInterest.getPrincpal();
		rate = simpleInterest.getRate();
		time = simpleInterest.getTime();
		result = (principal * rate * time) / 100;
		return result;
	}
}
